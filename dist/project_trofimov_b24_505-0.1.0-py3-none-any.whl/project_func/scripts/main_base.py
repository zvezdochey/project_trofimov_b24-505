#!/usr/bin/env python3

from project_func.cli import welcome


def main():
    print('Первая попытка запустить проект!\n***')
    welcome()
